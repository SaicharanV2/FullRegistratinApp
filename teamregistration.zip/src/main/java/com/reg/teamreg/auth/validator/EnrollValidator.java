package com.reg.teamreg.auth.validator;

import com.reg.teamreg.auth.model.EnrollTeam;
import com.reg.teamreg.auth.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import java.util.List;

@Component
public class EnrollValidator implements Validator {
    @Autowired
    private UserService userService;

    @Override
    public boolean supports(Class<?> aClass) {
        return EnrollTeam.class.equals(aClass);
    }

    @Override
    public void validate(Object o, Errors errors) {
        EnrollTeam enrollTeam = (EnrollTeam) o;

        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "team_name", "NotEmpty");
        if (enrollTeam.getTeam_name().length() < 4 || enrollTeam.getTeam_name().length() > 32) {
            errors.rejectValue("team_name", "Size.entrollTeam.team_name");
        }
    }

    public String validate(Object o) {
        EnrollTeam enrollTeam = (EnrollTeam) o;
        String errors = "";
        if (enrollTeam.getTeam_name().length() < 4 || enrollTeam.getTeam_name().length() > 32) {
            errors += "Team Name should be in between 4 and 32 characters";
        }
        return errors;
    }

    public String validate(List<EnrollTeam> enrollTeam) {
        String errors = "";
        if(enrollTeam.size() > 4) {
            errors += "Team Members limited to 4";
        }
        return errors;
    }
}
