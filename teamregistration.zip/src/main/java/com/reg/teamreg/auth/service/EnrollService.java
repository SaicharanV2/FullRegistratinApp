package com.reg.teamreg.auth.service;

import com.reg.teamreg.auth.model.EnrollTeam;

import java.util.LinkedList;
import java.util.List;

public interface EnrollService {
    void save(EnrollTeam enrollTeam);
    void saveAll(List<EnrollTeam> enrollTeam);
    List<EnrollTeam> findByUsername(String username);
    List<EnrollTeam> findAll();
    EnrollTeam findByUid(String uId);
    List<EnrollTeam> findByTeamName(String team_name);
    EnrollTeam findByUid(String uid, String username);
    void deleteByUsername(String username);
}
