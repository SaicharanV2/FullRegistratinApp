package com.reg.teamreg.auth.service;

import com.reg.teamreg.auth.model.Role;
import com.reg.teamreg.auth.model.User;
import com.reg.teamreg.auth.model.Volunteers;
import com.reg.teamreg.auth.repository.RoleRepository;
import com.reg.teamreg.auth.repository.UserRepository;
import com.reg.teamreg.auth.repository.VolunteerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.HashSet;
import java.util.List;

@Service
public class VolunteerServiceImpl implements VolunteerService {
    @Autowired
    private VolunteerRepository volunteerRepository;

    @Override
    public void save(Volunteers volunteers) {
        volunteerRepository.save(volunteers);
    }

    @Override
    public List<Volunteers> findAll() {
        return volunteerRepository.findAll();
    }

}