package com.reg.teamreg.auth.constants;

public class TeamConstants {
    public static final String ADMIN_USERNAME = "admin";
    public static final Boolean ENROLL_FINISH = true;
}
