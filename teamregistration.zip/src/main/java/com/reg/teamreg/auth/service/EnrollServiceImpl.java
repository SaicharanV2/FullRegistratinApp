package com.reg.teamreg.auth.service;

import com.reg.teamreg.auth.model.EnrollTeam;
import com.reg.teamreg.auth.repository.EnrollRepository;
import com.reg.teamreg.auth.repository.UserRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.stereotype.Service;

import java.util.LinkedList;
import java.util.List;

@Service
public class EnrollServiceImpl implements EnrollService{
    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private EnrollRepository enrollRepository;

    @Override
    public void save(EnrollTeam enrollTeam) {
        enrollRepository.save(enrollTeam);
    }

    @Override
    public void saveAll(List<EnrollTeam> enrollTeam) {
        enrollRepository.saveAll(enrollTeam);
    }

    @Override
    public List<EnrollTeam> findByUsername(String username) {
        return enrollRepository.findByUsername(username);
    }

    @Override
    public List<EnrollTeam> findAll() {
        return (List<EnrollTeam>) enrollRepository.findAll();
    }

    @Override
    public EnrollTeam findByUid(String uId) {
        return enrollRepository.findByUid(uId);
    }

    @Override
    public List<EnrollTeam> findByTeamName(String team_name) {
        return enrollRepository.findByTeamName(team_name);
    }


    @Override
    public EnrollTeam findByUid(String uid, String username) {
        return enrollRepository.findByUid(uid, username);
    }

    @Override
    public void deleteByUsername(String username) {
        enrollRepository.deleteByUsername(username);
    }
}