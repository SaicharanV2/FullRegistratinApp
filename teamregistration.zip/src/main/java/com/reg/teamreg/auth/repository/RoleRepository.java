package com.reg.teamreg.auth.repository;

import com.reg.teamreg.auth.model.Role;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RoleRepository extends JpaRepository<Role, Long>{
}