package com.reg.teamreg.auth.service;

import com.reg.teamreg.auth.model.Winners;
import com.reg.teamreg.auth.repository.WinnerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

@Service
public class WinnerServiceImpl implements WinnerService {
    @Autowired
    WinnerRepository winnerRepository;

    @Override
    public void saveAll(List<Winners> winners) {
        winnerRepository.saveAll(winners);
    }

    @Override
    public Winners findByMap(String map) {
        return winnerRepository.findByMap(map);
    }


}
