package com.reg.teamreg.auth.web;

import com.reg.teamreg.auth.constants.TeamConstants;
import com.reg.teamreg.auth.model.EnrollTeam;
import com.reg.teamreg.auth.model.User;
import com.reg.teamreg.auth.model.Volunteers;
import com.reg.teamreg.auth.service.EnrollService;
import com.reg.teamreg.auth.service.SecurityService;
import com.reg.teamreg.auth.service.UserService;
import com.reg.teamreg.auth.service.VolunteerService;
import com.reg.teamreg.auth.validator.VolunteerValidator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.List;

@Controller
public class AdminController {
    @Autowired
    private UserService userService;

    @Autowired
    private EnrollService enrollService;

    @Autowired
    private VolunteerService volunteerService;

    @Autowired
    private SecurityService securityService;

    @Autowired
    private VolunteerValidator volunteerValidator;

    @GetMapping("/viewteams")
    public String viewteams(Model model, Authentication authentication) {
        if (!TeamConstants.ADMIN_USERNAME.equals(authentication.getName())) {
            return "redirect:/welcome";
        }
        List<EnrollTeam> results = enrollService.findAll();
        model.addAttribute("results", results);

        return "admin-teams-view";
    }

    @GetMapping("/viewusers")
    public String viewusers(Model model, Authentication authentication) {
        if (!TeamConstants.ADMIN_USERNAME.equals(authentication.getName())) {
            return "redirect:/welcome";
        }
        List<User> users = userService.findAll();
        model.addAttribute("users", users);
        return "admin-users-view";
    }

    @GetMapping("/addvolunteers")
    public String addvolunteers(Model model, Authentication authentication) {
        if (!TeamConstants.ADMIN_USERNAME.equals(authentication.getName())) {
            return "redirect:/welcome";
        }
        model.addAttribute("volunteerForm", new Volunteers());
        return "volunteer-add";
    }

    @PostMapping("/addvolunteers")
    public String addvolunteers(@ModelAttribute("volunteerForm") Volunteers volunteerForm, BindingResult bindingResult) {
        volunteerValidator.validate(volunteerForm, bindingResult);

        if (bindingResult.hasErrors()) {
            return "volunteer-add";
        }

        volunteerService.save(volunteerForm);

        return "redirect:/volunteers";
    }

    @GetMapping("/volunteers")
    public String volunteers(Model model, Authentication authentication) {
        if (!TeamConstants.ADMIN_USERNAME.equals(authentication.getName())) {
            return "redirect:/welcome";
        }
        List<Volunteers> results = volunteerService.findAll();
        model.addAttribute("results", results);
        return "volunteer-view";
    }

}
