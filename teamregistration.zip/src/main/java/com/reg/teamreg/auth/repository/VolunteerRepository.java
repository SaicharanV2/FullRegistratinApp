package com.reg.teamreg.auth.repository;

import com.reg.teamreg.auth.model.Role;
import com.reg.teamreg.auth.model.Volunteers;
import org.springframework.data.jpa.repository.JpaRepository;

public interface VolunteerRepository extends JpaRepository<Volunteers, Long>{
}