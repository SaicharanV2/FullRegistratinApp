package com.reg.teamreg.auth.model;

import org.springframework.beans.factory.annotation.Autowired;

import javax.persistence.*;

@Entity
public class Winners {
    @Id
    private Long id=1L;
    @Column(nullable = false)
    private String team_name2;
    @Column(nullable = false)
    private String team_name3;
    @Column(nullable = false)
    private String team_name;
    private String map="mapping";
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    @Override
    public String toString() {
        return "Winners{" +
                "id=" + id +
                ", team_name2='" + team_name2 + '\'' +
                ", team_name3='" + team_name3 + '\'' +
                ", team_name='" + team_name + '\'' +
                '}';
    }

    public String getTeam_name() {
        return team_name;
    }

    public void setTeam_name(String team_name) {
        this.team_name = team_name;
    }

    public String getTeam_name2() {
        return team_name2;
    }

    public void setTeam_name2(String team_name2) {
        this.team_name2 = team_name2;
    }

    public String getTeam_name3() {
        return team_name3;
    }

    public void setTeam_name3(String team_name3) {
        this.team_name3 = team_name3;
    }


}
