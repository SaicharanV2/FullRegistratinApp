package com.reg.teamreg.auth.repository;

import com.reg.teamreg.auth.model.Winners;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface WinnerRepository extends JpaRepository<Winners,Long> {
    Winners findByMap(String map);
}
