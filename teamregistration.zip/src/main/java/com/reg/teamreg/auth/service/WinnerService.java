package com.reg.teamreg.auth.service;

import com.reg.teamreg.auth.model.Winners;

import java.util.List;

public interface WinnerService {
    void saveAll(List<Winners> winners);
    Winners findByMap(String map);
}
