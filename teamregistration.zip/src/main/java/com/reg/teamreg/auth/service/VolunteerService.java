package com.reg.teamreg.auth.service;

import com.reg.teamreg.auth.model.User;
import com.reg.teamreg.auth.model.Volunteers;

import java.util.List;

public interface VolunteerService {
    void save(Volunteers volunteers);
    List<Volunteers> findAll();
}
