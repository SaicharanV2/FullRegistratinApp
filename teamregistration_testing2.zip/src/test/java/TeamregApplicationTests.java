import com.reg.teamreg.auth.web.AdminController;
import com.reg.teamreg.auth.web.TeamController;
import com.reg.teamreg.auth.web.UserController;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
class TeamregApplicationTests {
	@Autowired
	AdminController adminController;
	@Autowired
	TeamController teamController;
	@Autowired
	UserController userController;
	@Test
	public void contexLoads() throws Exception {
		assertThat(adminController).isNotNull();
		assertThat(teamController).isNotNull();
		assertThat(userController).isNotNull();
	}

}
