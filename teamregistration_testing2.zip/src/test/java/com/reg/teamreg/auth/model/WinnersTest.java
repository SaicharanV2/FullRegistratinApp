package com.reg.teamreg.auth.model;

import com.reg.teamreg.auth.model.Volunteers;
import com.reg.teamreg.auth.model.Winners;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

public class WinnersTest {

    Winners winners=new Winners(1L,"A","B","C","true");
    @Test
    public void UserTest(){
        assertThat(winners.getTeam_name()).isEqualTo("C");
        assertThat(winners.getId()).isNotNull();
        assertThat(winners.getTeam_name2()).isNotNull();
        assertThat(winners.getTeam_name3()).isNotNull();
    }
}
