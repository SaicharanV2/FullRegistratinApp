package com.reg.teamreg.auth.service;

import com.reg.teamreg.auth.model.Winners;
import com.reg.teamreg.auth.repository.WinnerRepository;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.*;

@RunWith(SpringRunner.class)
@SpringBootTest
class WinnerServiceImplTest {
    @Autowired
    WinnerRepository winnerRepository;

    Winners winners=new Winners(1L,"A","B","C","true");

    @Test
    void saveAll() {
        winnerRepository.save(winners);
        assertThat(winnerRepository.findById(1L)).isNotNull();

    }

    @Test
    void findByMap() {
        assertThat(winnerRepository.findByMap("true").getTeam_name()).isEqualTo("C");
    }
}