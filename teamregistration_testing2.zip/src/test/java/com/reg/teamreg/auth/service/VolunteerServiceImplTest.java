package com.reg.teamreg.auth.service;

import com.reg.teamreg.auth.model.Volunteers;
import com.reg.teamreg.auth.repository.VolunteerRepository;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.*;

@RunWith(SpringRunner.class)
@SpringBootTest
class VolunteerServiceImplTest {
    @Autowired
    VolunteerRepository volunteerRepository;

    Volunteers volunteers=new Volunteers(1L,"abcdefgh","","abcdefgh","abcdefgh@dfds.gf","Male","M","Veg","Trivandrum","Efx");

    @Test
    void save() {
        volunteerRepository.save(volunteers);
        assertThat(volunteerRepository.findById(1L)).isNotNull();

    }

    @Test
    void findAll() {
        assertThat(volunteerRepository.count()).isNotNull();
    }
}