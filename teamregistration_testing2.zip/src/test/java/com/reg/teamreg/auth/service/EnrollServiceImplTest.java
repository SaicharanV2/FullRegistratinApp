package com.reg.teamreg.auth.service;
import static org.mockito.Mockito.*;

import com.reg.teamreg.auth.model.EnrollTeam;
import com.reg.teamreg.auth.repository.EnrollRepository;
import org.junit.Before;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Bean;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Collections;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.*;
@RunWith(SpringRunner.class)
@SpringBootTest
class EnrollServiceImplTest {
    @TestConfiguration
    static class EnrollServiceImplTestContextConfiguration {
        @Bean
        public EnrollService enrollService() {
            return new EnrollServiceImpl();
        }
    }
    @Autowired
    private EnrollService enrollService;

    @MockBean
    EnrollRepository enrollRepository;


    @Before
    public void setUp() {
        EnrollTeam enrollTeam=new EnrollTeam(1L,"saicharan","efx","saicharan","saicharan","saicharan","abcdefgh@dfds.gf","Male","M","Veg","Trivandrum","saicharan");

        Mockito.when(enrollRepository.findByUid("saicharan").getUsername()).thenReturn("saicharan");
        Mockito.when(enrollRepository.findByUsername("saicharan")).thenReturn((List<EnrollTeam>) enrollTeam);

    }


   @Test
    void save() {
       List<EnrollTeam> found = enrollService.findAll();
       assertThat(found.size()).isNotNull();
       assertNotNull(enrollRepository.count());
    }

    @Test
    void saveAll() {
        assertNotNull(enrollRepository.count());
    }

    @Test
    void findByUsername() {
        EnrollTeam foundByUsername = enrollService.findByUid("saicharan");
        assertThat(foundByUsername.getUsername()).isEqualTo("saicharan");

    }

    @Test
    void findAll() {
        assertNotNull(enrollRepository.findAll());

    }

    @Test
    void findByUid() {
        Mockito.when(enrollRepository.findByUid("saicharan").getId()).thenReturn(1L);


    }

    @Test
    void findByTeamName() {
        when(enrollRepository.findByTeamName("efx")).thenReturn(Collections.emptyList());
        System.out.println(enrollRepository.count());
        assertThat(enrollRepository.findByTeamName("saicharan")).isNotNull();
    }


    @Test
    void deleteByUsername() {
     enrollRepository.deleteByUsername("saicharan");
       assertThat(enrollRepository.findByUid("saicharan")).isNull();
    }
}