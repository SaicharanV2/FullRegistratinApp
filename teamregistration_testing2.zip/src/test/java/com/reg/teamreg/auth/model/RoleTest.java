package com.reg.teamreg.auth.model;

import com.reg.teamreg.auth.model.Role;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import static org.assertj.core.api.Assertions.assertThat;


public class RoleTest {
    Role role=new Role(1L,"Admin");
    @Test
    public void roleTest(){
        assertThat(role.getName()).isNotNull();
        assertThat(role.getName()).isEqualTo("Admin");
        assertThat(role.getId()).isNotNull();
    }

}
