package com.reg.teamreg.auth.model;

import com.reg.teamreg.auth.model.EnrollTeam;
import com.reg.teamreg.auth.model.Volunteers;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import static org.assertj.core.api.Assertions.assertThat;

public class VolunteerTest {

    Volunteers volunteers=new Volunteers(1L,"abcdefgh","","abcdefgh","abcdefgh@dfds.gf","Male","M","Veg","Trivandrum","Efx");
    @Test
    public void UserTest(){
        assertThat(volunteers.getUid()).isEqualTo("abcdefgh");
        assertThat(volunteers.getId()).isNotNull();
        assertThat(volunteers.getEfx_id()).isNotNull();
        assertThat(volunteers.getEmp_name()).isNotNull();
        assertThat(volunteers.getFood_type()).isNotNull();
        assertThat(volunteers.getLocation()).isEqualTo("Trivandrum");
        assertThat(volunteers.getTshirt_size()).isNotNull();
    }
}
