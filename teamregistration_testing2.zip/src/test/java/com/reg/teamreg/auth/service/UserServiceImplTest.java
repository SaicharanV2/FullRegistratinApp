package com.reg.teamreg.auth.service;

import com.reg.teamreg.auth.model.User;
import com.reg.teamreg.auth.repository.UserRepository;
import com.reg.teamreg.auth.repository.VolunteerRepository;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.*;
@RunWith(SpringRunner.class)
@SpringBootTest
class UserServiceImplTest {
    @Autowired
    UserRepository userRepository;
    User user=new User(1L,"abcdefgh","abcdefgh","abcdefgh");
    @Test
    void save() {
        userRepository.save(user);
        assertThat(userRepository.findById(1L)).isNotNull();
    }

    @Test
    void findAll() {
        assertThat(userRepository.count()).isNotNull();
    }

    @Test
    void findByUsername() {
        assertThat(userRepository.findByUsername("abcdefgh").getUsername()).isEqualTo("l");

    }
}