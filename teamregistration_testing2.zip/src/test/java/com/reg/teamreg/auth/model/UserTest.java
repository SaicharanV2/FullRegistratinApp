package com.reg.teamreg.auth.model;

import com.reg.teamreg.auth.model.Role;
import com.reg.teamreg.auth.model.User;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import static org.assertj.core.api.Assertions.assertThat;

public class UserTest {

    User user=new User(1L,"abcdefgh","abcdefgh","abcdefgh");
    @Test
    public void UserTest(){
        assertThat(user.getUsername()).isEqualTo("abcdefgh");
        assertThat(user.getId()).isNotNull();
        assertThat(user.getPassword()).isNotNull();
    }
}
