package com.reg.teamreg.auth.constants;

import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

public class TeamConstantsTest {

TeamConstants teamConstants=new TeamConstants();
    @Test
    public void TeamConstantsTest(){
        assertThat(teamConstants.ADMIN_USERNAME).isNotNull();
        assertThat(teamConstants.ENROLL_FINISH).isNotNull();
    }
}
