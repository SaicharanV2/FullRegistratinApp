package com.reg.teamreg.auth.model;
import com.reg.teamreg.auth.model.EnrollTeam;
import org.junit.jupiter.api.Test;

import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import static org.assertj.core.api.Assertions.assertThat;


public class EnrollTeamTest {

    EnrollTeam enrollTeam=new EnrollTeam(1L,"abcdefgh","abcdefgh","abcdefgh","abcdefgh","abcdefgh","abcdefgh@dfds.gf","Male","M","Veg","Trivandrum","abcdefgh");
    @Test
    public void UserTest(){
        assertThat(enrollTeam.getUsername()).isEqualTo("abcdefgh");
        assertThat(enrollTeam.getId()).isNotNull();
        assertThat(enrollTeam.getTeam_name()).isNotNull();
        assertThat(enrollTeam.getEmp_name()).isNotNull();
        assertThat(enrollTeam.getFood_type()).isNotNull();
        assertThat(enrollTeam.getLocation()).isEqualTo("Trivandrum");
        assertThat(enrollTeam.getTeam_name()).isNotNull();
    }
}
