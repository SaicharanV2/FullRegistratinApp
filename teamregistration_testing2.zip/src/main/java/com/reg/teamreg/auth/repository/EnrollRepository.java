package com.reg.teamreg.auth.repository;

import com.reg.teamreg.auth.model.EnrollTeam;
import com.reg.teamreg.auth.model.Role;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

public interface EnrollRepository extends JpaRepository<EnrollTeam, Long> {
    List<EnrollTeam> findByUsername(String username);

    EnrollTeam findByUid(String uId);

    @Query(value = "SELECT * from enrollteam e where e.team_name =:team_name", nativeQuery = true)
        // using @query
    List<EnrollTeam> findByTeamName(@Param("team_name") String team_name);

    @Query(value = "SELECT * from enrollteam e where e.uid =:uid AND e.username != :username", nativeQuery = true)
        // using @query
    EnrollTeam findByUid(@Param("uid") String uid, @Param("username") String username);

    @Modifying
    @Transactional
    @Query(value = "DELETE from enrollteam where username = :username", nativeQuery = true)
        // using @query
    void deleteByUsername(@Param("username") String username);
}