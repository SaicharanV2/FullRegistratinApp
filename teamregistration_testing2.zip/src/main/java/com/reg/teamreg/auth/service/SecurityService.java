package com.reg.teamreg.auth.service;

import org.springframework.security.core.userdetails.UserDetails;

public interface SecurityService {
    String findLoggedInUsername();
    String getLoggedInUsername();
    void autoLogin(String username, String password);
}