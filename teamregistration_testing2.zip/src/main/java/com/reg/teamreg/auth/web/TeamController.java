package com.reg.teamreg.auth.web;

import com.reg.teamreg.auth.constants.TeamConstants;
import com.reg.teamreg.auth.model.EnrollTeam;
import com.reg.teamreg.auth.model.Winners;
import com.reg.teamreg.auth.service.EnrollService;
import com.reg.teamreg.auth.service.SecurityService;
import com.reg.teamreg.auth.service.UserService;
import com.reg.teamreg.auth.service.WinnerService;
import com.reg.teamreg.auth.validator.EnrollValidator;
import com.reg.teamreg.auth.validator.UserValidator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.LinkedList;
import java.util.List;


@Controller
public class TeamController {
    @Autowired
    private UserService userService;

    @Autowired
    private WinnerService winnerService;

    @Autowired
    private EnrollService enrollService;

    @Autowired
    private SecurityService securityService;

    @Autowired
    private UserValidator userValidator;

    @Autowired
    private EnrollValidator enrollValidator;

    @GetMapping("/enroll")
    public String entroll(Model model, Authentication authentication) {
        if (TeamConstants.ADMIN_USERNAME.equals(authentication.getName())) {
            return "redirect:/welcome";
        }
        model.addAttribute("username", authentication.getName());

        List<EnrollTeam> enrollTeamList = enrollService.findByUsername(authentication.getName());
        if (enrollTeamList.size() > 0) {
            model.addAttribute("message", "Already registered your team");
        }
        if(TeamConstants.ENROLL_FINISH) {
            model.addAttribute("message", "Registration / Enrollment Date Completed");
            return "completed";
        } else {
            return "team-enroll";
        }
    }

    @PostMapping("/enroll")
    public String entroll(@RequestParam MultiValueMap multiValueMap, Model model) {
        String username = securityService.getLoggedInUsername();
        model.addAttribute("username", username);

        LinkedList<String> team_name = (LinkedList<String>) multiValueMap.get("team_name");

        LinkedList<String> uid = (LinkedList<String>) multiValueMap.get("uid[]");
        LinkedList<String> name = (LinkedList<String>) multiValueMap.get("name[]");
        LinkedList<String> efx_id = (LinkedList<String>) multiValueMap.get("efx_id[]");
        LinkedList<String> emp_mail = (LinkedList<String>) multiValueMap.get("emp_mail[]");
        LinkedList<String> emp_gender = (LinkedList<String>) multiValueMap.get("emp_gender[]");
        LinkedList<String> tshirt_size = (LinkedList<String>) multiValueMap.get("tshirt_size[]");
        LinkedList<String> food_type = (LinkedList<String>) multiValueMap.get("food_type[]");
        LinkedList<String> location = (LinkedList<String>) multiValueMap.get("location[]");
        LinkedList<String> emp_account = (LinkedList<String>) multiValueMap.get("emp_account[]");

        List<EnrollTeam> entrolTeamList = new LinkedList<>();
        String errors = "";
        for (String n : name) {
            EnrollTeam enrollTeam = new EnrollTeam();
            enrollTeam.setTeam_name(team_name.get(0));
            int index = name.indexOf(n);
            enrollTeam.setUsername(username);
            enrollTeam.setUid(uid.get(index));
            enrollTeam.setEmp_name(name.get(index));
            enrollTeam.setEfx_id(efx_id.get(index));
            enrollTeam.setEmp_email(emp_mail.get(index));
            enrollTeam.setEmp_gender(emp_gender.get(index));
            enrollTeam.setTshirt_size(tshirt_size.get(index));
            enrollTeam.setFood_type(food_type.get(index));
            enrollTeam.setEmp_account(emp_account.get(index));
            enrollTeam.setLocation(location.get(index));
            entrolTeamList.add(enrollTeam);

            errors += enrollValidator.validate(enrollTeam);
        }

        errors += enrollValidator.validate(entrolTeamList);

        if (errors.length() > 0) {
            model.addAttribute("errors", errors);
            return "team-enroll";
        } else {
            enrollService.saveAll(entrolTeamList);
        }
        return "redirect:/myteam";
    }


    @GetMapping("/winner-enroll")
    public String winnerEnroll(Model model, Authentication authentication) {
        if (TeamConstants.ADMIN_USERNAME.equals(authentication.getName())) {
            List<EnrollTeam> enrollTeamList = enrollService.findAll();
            model.addAttribute("enrollTeamList", enrollTeamList);
            return "winner-enroll";
        }
        return "No-Access";
    }

    @PostMapping("/winner-enroll")
    public String winnerEnroll(@RequestParam MultiValueMap multiValueMap, Model model) {
        LinkedList<String> team_name = (LinkedList<String>) multiValueMap.get("team_name");
        LinkedList<String> team_name2 = (LinkedList<String>) multiValueMap.get("team_name2");
        LinkedList<String> team_name3 = (LinkedList<String>) multiValueMap.get("team_name3");
        List<Winners> winnersList = new LinkedList<>();
        Winners winners = new Winners();
        winners.setTeam_name(team_name.get(0));
        winners.setTeam_name2(team_name2.get(0));
        winners.setTeam_name3(team_name3.get(0));
        winnersList.add(winners);
        winnerService.saveAll(winnersList);
        return "redirect:/viewwinners";
    }

    @GetMapping("/viewwinners")
    public String viewwinners(Model model, Authentication authentication) {
        Winners winnersList2 = winnerService.findByMap("mapping");
        if(winnersList2 != null) {
            String winner1 = winnersList2.getTeam_name();
            String winner2 = winnersList2.getTeam_name2();
            String winner3 = winnersList2.getTeam_name3();

            List<EnrollTeam> enrollTeam1 = enrollService.findByTeamName(winner1);
            List<EnrollTeam> enrollTeam2 = enrollService.findByTeamName(winner2);
            List<EnrollTeam> enrollTeam3 = enrollService.findByTeamName(winner3);
            model.addAttribute("enrollTeam1", enrollTeam1);
            model.addAttribute("enrollTeam2", enrollTeam2);
            model.addAttribute("enrollTeam3", enrollTeam3);
        } else {
            // model.addAttribute("message", "Registration / Enrollment Date Completed");
        }
        return "winner-display";
    }


    @GetMapping("/myteam")
    public String myteam(Model model, Authentication authentication) {
        if (TeamConstants.ADMIN_USERNAME.equals(authentication.getName())) {
            return "redirect:/welcome";
        }
        String username = securityService.getLoggedInUsername();
        model.addAttribute("username", username);

        List<EnrollTeam> enrollTeamList = enrollService.findByUsername(username);
        model.addAttribute("enrollTeamList", enrollTeamList);
        return "team-view";
    }

    @GetMapping("/checkuid")
    public ResponseEntity<?> checkuid(@RequestParam String uid, @RequestParam(name="edit", defaultValue = "false") Boolean edit) {
        String username = securityService.getLoggedInUsername();
        String message = "";
        if(edit) {
            if (enrollService.findByUid(uid, username) != null) {
                message = "UID already registered in another team";
            }
        } else {
            if (enrollService.findByUid(uid) != null) {
                message = "UID already registered in another team";
            }
        }

        return ResponseEntity.ok(message);

    }

    @GetMapping("/editteam")
    public String editteam(Model model, Authentication authentication) {
        if (TeamConstants.ADMIN_USERNAME.equals(authentication.getName())) {
            return "redirect:/welcome";
        }
        String username = securityService.getLoggedInUsername();
        model.addAttribute("username", username);

        List<EnrollTeam> enrollTeamList = enrollService.findByUsername(username);
        model.addAttribute("enrollTeamList", enrollTeamList);

        if(TeamConstants.ENROLL_FINISH) {
            model.addAttribute("message", "Registration / Enrollment Date Completed");
            return "completed";
        } else {
            return "team-edit";
        }
    }

    @PostMapping("/editteam")
    public String editteam(@RequestParam MultiValueMap multiValueMap, Model model) {
        String username = securityService.getLoggedInUsername();
        model.addAttribute("username", username);

        LinkedList<String> team_name = (LinkedList<String>) multiValueMap.get("team_name");

        LinkedList<String> id = (LinkedList<String>) multiValueMap.get("id[]");
        LinkedList<String> uid = (LinkedList<String>) multiValueMap.get("uid[]");
        LinkedList<String> name = (LinkedList<String>) multiValueMap.get("name[]");
        LinkedList<String> efx_id = (LinkedList<String>) multiValueMap.get("efx_id[]");
        LinkedList<String> emp_mail = (LinkedList<String>) multiValueMap.get("emp_mail[]");
        LinkedList<String> emp_gender = (LinkedList<String>) multiValueMap.get("emp_gender[]");
        LinkedList<String> tshirt_size = (LinkedList<String>) multiValueMap.get("tshirt_size[]");
        LinkedList<String> food_type = (LinkedList<String>) multiValueMap.get("food_type[]");
        LinkedList<String> location = (LinkedList<String>) multiValueMap.get("location[]");
        LinkedList<String> emp_account = (LinkedList<String>) multiValueMap.get("emp_account[]");


        List<EnrollTeam> entrolTeamList = new LinkedList<>();
        String errors = "";
        for (String n : name) {
            EnrollTeam enrollTeam = new EnrollTeam();
            enrollTeam.setTeam_name(team_name.get(0));
            int index = name.indexOf(n);
            /*if(id.get(index) != "") {
                enrollTeam.setId(Long.valueOf(id.get(index)));
            }*/
            enrollTeam.setUsername(username);
            enrollTeam.setUid(uid.get(index));
            enrollTeam.setEmp_name(name.get(index));
            enrollTeam.setEfx_id(efx_id.get(index));
            enrollTeam.setEmp_email(emp_mail.get(index));
            enrollTeam.setEmp_gender(emp_gender.get(index));
            enrollTeam.setTshirt_size(tshirt_size.get(index));
            enrollTeam.setFood_type(food_type.get(index));
            enrollTeam.setEmp_account(emp_account.get(index));
            enrollTeam.setLocation(location.get(index));
            enrollTeam.setEmp_account(emp_account.get(index));
            enrollTeam.setLocation(location.get(index));
            entrolTeamList.add(enrollTeam);

            errors += enrollValidator.validate(enrollTeam);
        }

        errors += enrollValidator.validate(entrolTeamList);

        if (errors.length() > 0) {
            model.addAttribute("errors", errors);
            return "team-edit";
        } else {
            enrollService.deleteByUsername(username);
            enrollService.saveAll(entrolTeamList);
        }

        return "redirect:/myteam";
    }

}
