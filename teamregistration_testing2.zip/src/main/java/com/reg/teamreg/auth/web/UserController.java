package com.reg.teamreg.auth.web;

import com.reg.teamreg.auth.constants.TeamConstants;
import com.reg.teamreg.auth.model.User;
import com.reg.teamreg.auth.service.EnrollService;
import com.reg.teamreg.auth.service.SecurityService;
import com.reg.teamreg.auth.service.UserService;
import com.reg.teamreg.auth.validator.EnrollValidator;
import com.reg.teamreg.auth.validator.UserValidator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class UserController {
    @Autowired
    private UserService userService;

    @Autowired
    private EnrollService enrollService;

    @Autowired
    private SecurityService securityService;

    @Autowired
    private UserValidator userValidator;

    @Autowired
    private EnrollValidator enrollValidator;

    @GetMapping("/registration")
    public String registration(Model model) {
        model.addAttribute("userForm", new User());

        if(TeamConstants.ENROLL_FINISH) {
            model.addAttribute("message", "Registration / Enrollment Date Completed");
            return "completed";
        } else {
            return "user-registration";
        }
    }

    @PostMapping("/registration")
    public String registration(@ModelAttribute("userForm") User userForm, BindingResult bindingResult) {
        userValidator.validate(userForm, bindingResult);

        if (bindingResult.hasErrors()) {
            return "user-registration";
        }

        userService.save(userForm);

        securityService.autoLogin(userForm.getUsername(), userForm.getPasswordConfirm());

        return "redirect:/welcome";
    }

    @GetMapping("/login")
    public String login(Model model, String error, String logout) {
        if (error != null)
            model.addAttribute("error", "Your username or password is invalid.");

        if (logout != null)
            model.addAttribute("message", "You have been logged out successfully.");

        return "user-login";
    }

    @GetMapping({"/", "/welcome"})
    public String welcome(Model model, Authentication authentication) {
        if (TeamConstants.ADMIN_USERNAME.equals(authentication.getName())) {
            return "admin-welcome";
        } else {
            return "user-welcome";
        }
    }

}
