package com.reg.teamreg.auth.model;

import org.springframework.beans.factory.annotation.Autowired;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "volunteers")
public class Volunteers {
    public Volunteers() {
    }

    public Volunteers(Long id, String uid, String emp_name, String efx_id, String emp_email, String emp_gender, String tshirt_size, String food_type, String location, String emp_account) {
        this.id = id;
        this.uid = uid;
        this.emp_name = emp_name;
        this.efx_id = efx_id;
        this.emp_email = emp_email;
        this.emp_gender = emp_gender;
        this.tshirt_size = tshirt_size;
        this.food_type = food_type;
        this.location = location;
        this.emp_account = emp_account;
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true)
    private String uid;
    @Column(nullable = false)
    private String emp_name;
    @Column(nullable = false)
    private String efx_id;
    @Column(nullable = false)
    private String emp_email;
    @Column(nullable = false)
    private String emp_gender;
    @Column(nullable = false)
    private String tshirt_size;
    @Column(nullable = false)
    private String food_type;
    @Column(nullable = false)
    private String location;
    @Column(nullable = false)
    private String emp_account;
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "created")
    private Date created=new Date();

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getEmp_name() {
        return emp_name;
    }

    public void setEmp_name(String emp_name) {
        this.emp_name = emp_name;
    }

    public String getEfx_id() {
        return efx_id;
    }

    public void setEfx_id(String efx_id) {
        this.efx_id = efx_id;
    }

    public String getEmp_email() {
        return emp_email;
    }

    public void setEmp_email(String emp_email) {
        this.emp_email = emp_email;
    }

    public String getEmp_gender() {
        return emp_gender;
    }

    public void setEmp_gender(String emp_gender) {
        this.emp_gender = emp_gender;
    }

    public String getTshirt_size() {
        return tshirt_size;
    }

    public void setTshirt_size(String tshirt_size) {
        this.tshirt_size = tshirt_size;
    }

    public String getFood_type() {
        return food_type;
    }

    public void setFood_type(String food_type) {
        this.food_type = food_type;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getEmp_account() {
        return emp_account;
    }

    public void setEmp_account(String emp_account) {
        this.emp_account = emp_account;
    }

    public Date getCreated() {
        return created;
    }

    public void setCreated(Date created) {
        this.created = created;
    }

}
