package com.reg.teamreg.auth.validator;

import com.reg.teamreg.auth.model.EnrollTeam;
import com.reg.teamreg.auth.model.Volunteers;
import com.reg.teamreg.auth.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

@Component
public class VolunteerValidator implements Validator {
    @Autowired
    private UserService userService;

    @Override
    public boolean supports(Class<?> aClass) {
        return Volunteers.class.equals(aClass);
    }

    @Override
    public void validate(Object o, Errors errors) {
        Volunteers volunteers = (Volunteers) o;

        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "efx_id", "NotEmpty");
        if (volunteers.getEfx_id().length() < 3 || volunteers.getEfx_id().length() > 8) {
            errors.rejectValue("efx_id", "Size.volunteer.efxid");
        }
    }
}
