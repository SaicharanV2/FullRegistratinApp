$(document).ready(function() {

 var myLanguage = {
     errorTitle: 'Form submission failed!',
     requiredFields: 'You have not answered all required fields',
     badTime: 'You have not given a correct time',
     badEmail: 'You have not given a correct e-mail address',
     badTelephone: 'You have not given a correct phone number',
     badSecurityAnswer: 'You have not given a correct answer to the security question',
     badDate: 'You have not given a correct date',
     lengthBadStart: 'Value must be between ',
     lengthBadEnd: ' characters',
     lengthTooLongStart: 'The input value is longer than ',
     lengthTooShortStart: 'Value is shorter than ',
     notConfirmed: 'Input values could not be confirmed',
     badDomain: 'Incorrect domain value',
     badUrl: 'Value is not a correct URL',
     badCustomVal: 'Value is incorrect',
     andSpaces: ' and spaces ',
     badInt: 'Value was not a correct number',
     badSecurityNumber: 'Your social security number was incorrect',
     badUKVatAnswer: 'Incorrect UK VAT Number',
     badStrength: 'The password isn\'t strong enough',
     badNumberOfSelectedOptionsStart: 'You have to choose at least ',
     badNumberOfSelectedOptionsEnd: ' answers',
     badAlphaNumeric: 'Value can only contain alphanumeric characters ',
     badAlphaNumericExtra: ' and ',
     wrongFileSize: 'The file you are trying to upload is too large (max %s)',
     wrongFileType: 'Only files of type %s is allowed',
     groupCheckedRangeStart: 'Please choose between ',
     groupCheckedTooFewStart: 'Please choose at least ',
     groupCheckedTooManyStart: 'Please choose a maximum of ',
     groupCheckedEnd: ' item(s)',
     badCreditCard: 'The credit card number is not correct',
     badCVV: 'The CVV number was not correct',
     wrongFileDim : 'Incorrect image dimensions,',
     imageTooTall : 'the image can not be taller than',
     imageTooWide : 'the image can not be wider than',
     imageTooSmall : 'the image was too small',
     min : 'min',
     max : 'max',
     imageRatioNotAccepted : 'Image ratio is not accepted'
 };

$.validate({
 language : myLanguage
});

 $("#add_row").on("click", function() {
  // Dynamic Rows Code

  // Get max row id and set new id
  var newid = 0;
  var maxcnt = $('#tab_logic tr').length;
  $.each($("#tab_logic tr"), function() {
   if (parseInt($(this).data("id")) > newid) {
    newid = parseInt($(this).data("id"));
   }
  });
  // console.log(newid);
  if (maxcnt <= 4) {
   if (maxcnt == 4) {
    $("#add_row").hide();
   }
   newid++;

   var tr = $("<tr></tr>", {
    id: "addr" + newid,
    "data-id": newid
   });

   // loop through each td and create new elements with name of newid
   $.each($("#tab_logic tbody tr:nth(0) td"), function() {
    var td;
    var cur_td = $(this);

    var children = cur_td.children();

    // add new td and element if it has a nane
    if ($(this).data("name") !== undefined) {
     td = $("<td></td>", {
      "data-name": $(cur_td).data("name")
     });

     var c = $(cur_td).find($(children[0]).prop('tagName')).clone().val("");
     //c.attr("name", $(cur_td).data("name") + newid);
     c.attr("name", $(cur_td).data("name") + "[]");
     c.appendTo($(td));
     td.appendTo($(tr));
    } else {
     td = $("<td></td>", {
      'text': $('#tab_logic tr').length
     }).appendTo($(tr));
    }
   });

   // add delete button and td
   /*
   $("<td></td>").append(
       $("<button class='btn btn-danger glyphicon glyphicon-remove row-remove'></button>")
           .click(function() {
               $(this).closest("tr").remove();
           })
   ).appendTo($(tr));
   */

   // add the new row
   $(tr).appendTo($('#tab_logic'));

    $("button.row-remove").on("click", function() {
           // $(tr).find("td button.row-remove").on("click", function() {
            $(this).closest("tr").remove();
            $("#add_row").show();
       });

  } else {
   // console.log("FILL");
  }
 });

    $("button.row-remove").on("click", function() {
       // $(tr).find("td button.row-remove").on("click", function() {
        $(this).closest("tr").remove();
        $("#add_row").show();
   });

 // Sortable Code
 var fixHelperModified = function(e, tr) {
  var $originals = tr.children();
  var $helper = tr.clone();

  $helper.children().each(function(index) {
   $(this).width($originals.eq(index).width())
  });

  return $helper;
 };

 /*$(".table-sortable tbody").sortable({
     helper: fixHelperModified
 }).disableSelection();

 $(".table-sortable thead").disableSelection();*/
 //$("#add_row").trigger("click");
});


function submitEntrollForm(e) {
 e.preventDefault();
 alert('ss');
}

function checkuid(e, t, v, edit = false) {
 if (v == '') {
  return true;
 }
 var iid = $(t).parent().parent().attr("id");

 $('#' + iid + ' td').removeClass('has-error');
 $('#' + iid + ' span').remove(".help-block");
 $("#addteam").show();
 // console.log(v);
 //var search = {}
 //search["uid"] = v;
 console.log(t);
 $.ajax({
  type: "GET",
  contentType: "application/json",
  url: "/cloud9/checkuid?uid=" + v + "&edit=" + edit,
  //data: JSON.stringify(search),
  //dataType: 'json',
  //cache: false,
  //timeout: 600000,
  success: function(data) {
   if (data != '') {
    $(t).parent().addClass('has-error');
    $(t).parent().append("<span class='help-block form-error'>" + data + "</span>");
    $("#addteam").hide();
   }
   /*var json = "<h4>Ajax Response</h4>&lt;pre&gt;"
       + JSON.stringify(data, null, 4) + "&lt;/pre&gt;";
   $('#feedback').html(json);

   console.log("SUCCESS : ", data);
   $("#btn-search").prop("disabled", false);*/

  },
  error: function(e) {

   /*var json = "<h4>Ajax Response</h4>&lt;pre&gt;"
       + e.responseText + "&lt;/pre&gt;";
   $('#feedback').html(json);

   console.log("ERROR : ", e);
   $("#btn-search").prop("disabled", false);*/

  }
 });
}