/*
SQLyog Community v13.1.5  (64 bit)
MySQL - 8.0.18 : Database - cloud9_registration
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`cloud9_registration` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `cloud9_registration`;

/*Table structure for table `enrollteam` */

DROP TABLE IF EXISTS `enrollteam`;

CREATE TABLE `enrollteam` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `efx_id` varchar(255) NOT NULL,
  `emp_email` varchar(255) NOT NULL,
  `emp_gender` varchar(255) NOT NULL,
  `emp_name` varchar(255) NOT NULL,
  `food_type` varchar(255) NOT NULL,
  `team_name` varchar(255) NOT NULL,
  `tshirt_size` varchar(255) NOT NULL,
  `uid` varchar(255) DEFAULT NULL,
  `username` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UK_fkoaqds3d6py0umvj141sy2o3` (`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `enrollteam` */

insert  into `enrollteam`(`id`,`efx_id`,`emp_email`,`emp_gender`,`emp_name`,`food_type`,`team_name`,`tshirt_size`,`uid`,`username`) values 
(1,'dxj77','deepu.jayasree@equifax.com','Male','Deepu KJ','Non-veg','G Bots','XL','U47240','U47240'),
(2,'gxj35','geo.janet@equifax.com','Male','Geo Janet','Non-veg','G Bots','L','U46387','U47240'),
(3,'pxk133','prem.karanavar@equifax.com','Male','Prem Kumar','Non-veg','G Bots','M','U50362','U47240'),
(4,'jxn67','jithin.nair@equifax.com','Male','Jithin Nair','Non-veg','G Bots','XL','U47804','U47240'),
(5,'sxn176','satheesh.nair@equifax.com','Male','Satheesh','Non-veg','Team Tech Magicians','XL','U60819','U60819'),
(6,'nxa117','nimmy.augustine@equifax.com','Female','Nimmy Augustine','Non-veg','ALPHABET','S','u63201','u63201'),
(7,'axt325','Amith.Thomas@equifax.com','Male','Amith Thomas','Non-veg','ALPHABET','XXL','u63093','u63201'),
(8,'ask12','Amal.Kunnumpurath@equifax.com','Male','Amal Kunnumpurath','Non-veg','ALPHABET','M','u92299','u63201'),
(9,'jxn120','Jameesh.Nazeera@equifax.com','Male','Jameesh Nazeera','Non-veg','ALPHABET','M','u72722','u63201'),
(14,'vxc53','vijulin.chellason@equifax.com','Male','Vijulin Chellason','Veg','Team Hacksquad','L','U47139','U47139'),
(15,'axr281','ajaykumar.rayappa@equifax.com','Male','AjayKumar Rayappa','Veg','Team Hacksquad','M','U56813','U47139'),
(16,'axs914','abilash.sumangala@equifax.com','Male','Abilash Sumangala','Non-veg','Team Hacksquad','M','U76105','U47139'),
(17,'vxn77','vishnu.nair@equifax.com','Male','Vishnu Nair','Non-veg','Team Hacksquad','M','U80294','U47139'),
(18,'axs458','ajith.santhakumari@equifax.com','Male','Ajith Prasad S S','Non-veg','Fantastic Four','S','U43231','U43231'),
(19,'sxa364','sunish.alex@equifax.com','Male','Sunish Alex','Non-veg','Fantastic Four','S','U84807','U43231'),
(20,'sxp357','sini.prasanna@equifax.com','Female','Sini Prasanna','Veg','Fantastic Four','XXL','U28160','U43231'),
(21,'sxr312','sajita.renoy@equifax.com','Female','Sajita Renoy ','Non-veg','Fantastic Four','L','U42514','U43231'),
(22,'vxn48','vijitha.narayanan@equifax.com','Female','Vijitha Narayanan','Veg','Cloud Amigos','L','U52958','U52958'),
(23,'axh288','akhil.hariharan@equifax.com','Male','Akhil Hariharan','Non-veg','Cloud Amigos','M','U78774','U52958'),
(24,'sxa189','shine.abraham@equifax.com','Male','Shine Abraham','Non-veg','Cloud Amigos','XXL','U43658','U52958'),
(25,'dxs428','diya.suma@equifax.com','Female','Diya Suma','Non-veg','Cloud Amigos','XL','U68143','U52958'),
(30,'nxn44','nidheesh.namboodiri@equifax.com','Male','Nidheesh Namboodiri','Veg','Cloud Ninjas','XXXL','u52355','u52355'),
(31,'bxl70','binoosha.leela@equifax.com','Female','Binoosha Leela Velappan Nair','Non-veg','Cloud Ninjas','L','U42342','u52355'),
(32,'axs905','ajithkumar.somashekharan@equifax.com','Male','Ajith Kumar Ettivilayil Somasekharan','Non-veg','Cloud Ninjas','M','U73157','u52355'),
(33,'dxc312','dhanuj.cherian@equifax.com','Male','Dhanuj Cherian','Non-veg','Cloud Ninjas','L','U89239','u52355');

/*Table structure for table `role` */

DROP TABLE IF EXISTS `role`;

CREATE TABLE `role` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `role` */

insert  into `role`(`id`,`name`) values 
(1,'Employee'),
(2,'Admin');

/*Table structure for table `user` */

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `password` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `user` */

insert  into `user`(`id`,`password`,`username`) values 
(1,'$2a$10$OV2KDmcUckjq3ohDmrJsA.ruy1iptNnM4N/Qf4kzjylwsTqG5SC8q','u52355'),
(2,'$2a$10$w7czcJRSUi4m4Vvbh3XPjuh6qdS7b/yTTpL/lQbkBuyxHFiwYGPzm','u47804'),
(3,'$2a$10$D1Jx0zZeeslJI0sYpI0N9O30ymddebnLmchX1Ew0OExtytbv3BpyW','U54548'),
(4,'$2a$10$aBKh2VPimBonF/KiJ.YKw.hhdAtB5o0ke8qK2cM3ApmTS0FoCQgne','u28878'),
(5,'$2a$10$Ys9oU2HiuCmdFLJaxRnTguiaq4hwtxYcF.7huRUZ0VWjmbrqMlP/W','u12695'),
(6,'$2a$10$mhCstvRR/l5kbBhZ7BCa6.Tv.tXVuWT9iqr5V2UdRsZGOTH/Lk48m','U93608'),
(7,'$2a$10$L6WMK9d9JutZ9E7V3UOcWuduGnVE1ORav6FOxXvecI/vk2J4S49bK','145550'),
(8,'$2a$10$WM2.4xgokdSqeAM57lJ1.uvVh7W/bsThWx0MqUNNSMKISkTwsdFfy','U59689'),
(9,'$2a$10$j0DD9TZHpQXef9z12s8Qo.FgB1sF/oRQ61S1aCpz2ge7q484cXJF6','U47240'),
(10,'$2a$10$Kx6B/LkvB36r4uB9DdeV5erYyuw/1CNxWaTiRYVNjqkElW62kYyVK','U60819'),
(11,'$2a$10$tjDmV7oIyKplm9g4glpoL.445wbPRcw0sM0ggfTXUKtmwrXC26lK.','U83654'),
(12,'$2a$10$FfVA.AKsJM5Pm9U05A1siuVisbrkJPmijMnoO22t6zNDPD2sOKZXO','U55687'),
(13,'$2a$10$Mm.nAGNPmMNP4Z9j3K8B4ulv9MdHBD1Rt0MHNuVGuJT/gUYPbuBEW','U63660'),
(14,'$2a$10$6FGHZQXwy7VaiIHNfu0zx.HjBoBWf/rlgv1.83YOhfBWKfM87kg9m','u82705'),
(15,'$2a$10$GUHwL6VYLyin5jixB5teDOxfkWF9gIrJiPdFiGhb5L/9A46tf/12e','U59976'),
(16,'$2a$10$dnVviGejUvP.CFxfTyYR7e5vRLZzRdyIfmGhwlSk0dt2hF262XTPa','admin'),
(17,'$2a$10$ghEjS.FRvziPsoSQOo3zl.b2Ze/Zdq8GQh97NQCra3WDw94S/CfFW','u63201'),
(18,'$2a$10$gNI.uvKxB5Hm0WKGE70ukeckGmP3MSRy0PTKOe1MVZAjPqSbgdu..','U47139'),
(19,'$2a$10$8uHc8lKD0LyScIERN6CDFOtN34z3eRIVai0jBlQf1r.OYKWUFD.vq','u89249'),
(20,'$2a$10$Cukt49esCxlYRPDjCRU3V.t7A8UZ1/hPwYznQXMzCF9qNZBCfTTim','U43231'),
(21,'$2a$10$YNabJIF9LnJPLVzeBofqx.C3sL95jR76Z83N2PtnY3nl.YHfqdrGi','u80830'),
(22,'$2a$10$1mWQ7ulFVHQUgNT0U3Ammu71gQQlKYxWDn/1AN532zp61tXnkPqRK','xyz123'),
(23,'$2a$10$HtluyDci01Os7dIL78AHbub3lHswgjbZ7aE7A81ea32.W8nESpBEK','u36127'),
(24,'$2a$10$YDdoZv4WyigvWtG.6y8VMuo9MUd19OM5xkj9jspL7jtpqQ6wjzjXq','U52958'),
(25,'$2a$10$gUh.OBSvrOwpbYEoc0BQyuTvV8ezYj5buAAIMOsYOeG5298R9DejW','145929');

/*Table structure for table `user_roles` */

DROP TABLE IF EXISTS `user_roles`;

CREATE TABLE `user_roles` (
  `users_id` bigint(20) NOT NULL,
  `roles_id` bigint(20) NOT NULL,
  PRIMARY KEY (`users_id`,`roles_id`),
  KEY `FKj9553ass9uctjrmh0gkqsmv0d` (`roles_id`),
  CONSTRAINT `FK7ecyobaa59vxkxckg6t355l86` FOREIGN KEY (`users_id`) REFERENCES `user` (`id`),
  CONSTRAINT `FKj9553ass9uctjrmh0gkqsmv0d` FOREIGN KEY (`roles_id`) REFERENCES `role` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `user_roles` */

insert  into `user_roles`(`users_id`,`roles_id`) values 
(1,1),
(2,1),
(3,1),
(4,1),
(5,1),
(6,1),
(7,1),
(8,1),
(9,1),
(10,1),
(11,1),
(12,1),
(13,1),
(14,1),
(15,1),
(17,1),
(18,1),
(19,1),
(20,1),
(21,1),
(22,1),
(23,1),
(24,1),
(25,1),
(16,2);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
