/*
SQLyog Community v13.1.5  (64 bit)
MySQL - 8.0.18 : Database - cloud9_registration
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`cloud9_registration` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `cloud9_registration`;

/*Table structure for table `enrollteam` */

DROP TABLE IF EXISTS `enrollteam`;

CREATE TABLE `enrollteam` (
  `id` bigint(20) DEFAULT NULL,
  `efx_id` varchar(765) DEFAULT NULL,
  `emp_email` varchar(765) DEFAULT NULL,
  `emp_gender` varchar(765) DEFAULT NULL,
  `emp_name` varchar(765) DEFAULT NULL,
  `food_type` varchar(765) DEFAULT NULL,
  `team_name` varchar(765) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `tshirt_size` varchar(765) DEFAULT NULL,
  `uid` varchar(765) DEFAULT NULL,
  `username` varchar(765) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `emp_account` varchar(765) DEFAULT NULL,
  `location` varchar(765) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `enrollteam` */

insert  into `enrollteam`(`id`,`efx_id`,`emp_email`,`emp_gender`,`emp_name`,`food_type`,`team_name`,`tshirt_size`,`uid`,`username`,`created`,`emp_account`,`location`) values 
(197,'sxn176','satheesh.nair@equifax.com','Male','Satheesh','Non-veg','Thunder Storm','XL','U60819','U60819','2020-03-06 19:53:20','USIS','Trivandrum'),
(43,'axb378','akash.bhasy@equifax.com','Male','Akash Bahsy','Non-veg','Hack O’ Holics','XXXL','u49583','u49583','2020-03-03 14:30:25','GCS','Trivandrum'),
(44,'axp319','akhila.padmanabhan@equifax.com','Female','Akhila padmanabhan','Non-veg','Hack O’ Holics','L','u38371','u49583','2020-03-03 14:30:25','GCS','Trivandrum'),
(45,'axm682','arun.madathirajan@equifax.com','Male','Arun M R','Non-veg','Dominator','L','U63660','U63660','2020-03-03 15:24:08','International-UK','Kochi'),
(46,'uxp19','ullas.prabhakar@equifax.com','Male','Ullas Prabhakar','Non-veg','Dominator','M','U45754','U63660','2020-03-03 15:24:08','International-UK','Kochi'),
(47,'vxk190','vineeth.kurussithodi@equifax.com','Male','Vineeth Kurussithodi','Non-veg','Dominator','M','U51172','U63660','2020-03-03 15:24:08','International-UK','Kochi'),
(48,'sxd323','savio.dominic@equifax.com','Male','Savio Dominic','Veg','Dominator','M','U73830','U63660','2020-03-03 15:24:08','EWS','Kochi'),
(49,'bxr175','brahma.reddy@equifax.com','Male','Brahma Reddy Pulagum','Veg','CSK ','M','146670','146670','2020-03-03 17:34:59','EWS','Chennai'),
(50,'nxs315','naveen.selvaraj@equifax.com','Male','Naveen Selvaraj','Non-veg','CSK ','L','U67122','146670','2020-03-03 17:34:59','USIS','Chennai'),
(51,'sxc434','sudharson.chandrababu@equifax.com','Male','Sudharson Chandrababu','Non-veg','CSK ','S','U92107','146670','2020-03-03 17:34:59','EWS','Chennai'),
(52,'cxp240','chowdary.palacharla@equifax.com','Male','Chowdary Palacharla','Non-veg','CSK ','M','146681','146670','2020-03-03 17:34:59','International-Canada','Chennai'),
(57,'vxc53','vijulin.chellason@equifax.com','Male','Vijulin Chellason','Veg','Team Hacksquad','L','U47139','U47139','2020-03-04 09:54:26','International-UK','Trivandrum'),
(58,'axr281','ajaykumar.rayappa@equifax.com','Male','AjayKumar Rayappa','Veg','Team Hacksquad','M','U56813','U47139','2020-03-04 09:54:26','International-UK','Trivandrum'),
(59,'axs914','abilash.sumangala@equifax.com','Male','Abilash Sumangala','Non-veg','Team Hacksquad','M','U76105','U47139','2020-03-04 09:54:26','International-UK','Trivandrum'),
(60,'vxn77','vishnu.nair@equifax.com','Male','Vishnu Nair','Non-veg','Team Hacksquad','M','U80294','U47139','2020-03-04 09:54:26','International-UK','Trivandrum'),
(61,'dxs360','dipesh.srivastava@equifax.com','Male','Dipesh Srivastava','Veg','Cloud Smith','M','U59650','U59650','2020-03-04 10:53:35','USIS','Trivandrum'),
(62,'axp538','ananth.pradeepkumar@equifax.com','Male','Ananth Pradeepkumar','Non-veg','Cloud Smith','M','146822','U59650','2020-03-04 10:53:35','USIS','Trivandrum'),
(63,'rxj186','r.janwa@equifax.com','Male','Raj Janwa','Veg','Cloud Smith','M','145049','U59650','2020-03-04 10:53:35','USIS','Trivandrum'),
(64,'rxv117','Rajesh.vijayanandhan@equifax.com','Male','Rajesh Vijayanandhan','Non-veg','Cloud Smith','M','U55687','U59650','2020-03-04 10:53:35','USIS','Trivandrum'),
(65,'dxj77','deepu.jayasree@equifax.com','Male','Deepu KJ','Non-veg','G Bots','XXL','U47240','U47240','2020-03-04 11:31:22','EWS','Trivandrum'),
(66,'gxj35','geo.janet@equifax.com','Male','Geo Janet','Non-veg','G Bots','L','U46387','U47240','2020-03-04 11:31:22','EWS','Trivandrum'),
(67,'pxk133','prem.karanavar@equifax.com','Male','Prem Kumar','Non-veg','G Bots','L','U50362','U47240','2020-03-04 11:31:22','EWS','Trivandrum'),
(68,'jxn67','jithin.nair@equifax.com','Male','Jithin Nair','Non-veg','G Bots','XL','U47804','U47240','2020-03-04 11:31:22','EWS','Trivandrum'),
(69,'nxa117','nimmy.augustine@equifax.com','Female','Nimmy Augustine','Non-veg','ALPHABET','S','u63201','u63201','2020-03-04 11:54:29','USIS','Trivandrum'),
(70,'axt325','Amith.Thomas@equifax.com','Male','Amith Thomas','Non-veg','ALPHABET','XXL','u63093','u63201','2020-03-04 11:54:29','International-Canada','Kochi'),
(71,'ask12','Amal.Kunnumpurath@equifax.com','Male','Amal Kunnumpurath','Non-veg','ALPHABET','M','u92299','u63201','2020-03-04 11:54:29','USIS','Trivandrum'),
(72,'jxn120','Jameesh.Nazeera@equifax.com','Male','Jameesh Nazeera','Non-veg','ALPHABET','M','u72722','u63201','2020-03-04 11:54:29','USIS','Trivandrum'),
(73,'axs458','ajith.santhakumari@equifax.com','Male','Ajith Prasad S S','Non-veg','Hello World','S','U43231','U43231','2020-03-04 11:58:00','EWS','Trivandrum'),
(74,'sxa364','sunish.alex@equifax.com','Male','Sunish Alex','Non-veg','Hello World','S','U84807','U43231','2020-03-04 11:58:00','EWS','Trivandrum'),
(75,'sxp357','sini.prasanna@equifax.com','Female','Sini Prasanna','Veg','Hello World','XXL','U28160','U43231','2020-03-04 11:58:00','EWS','Trivandrum'),
(76,'sxr312','sajita.renoy@equifax.com','Female','Sajita Renoy ','Non-veg','Hello World','L','U42514','U43231','2020-03-04 11:58:00','EWS','Trivandrum'),
(77,'vxs237','varun.sreedevi@equifax.com','Male','Varun','Non-veg','AtCloud','L','U68142','U68142','2020-03-04 13:10:22','EWS','Trivandrum'),
(78,'axm756','aneesh.maniyappan@equifax.com','Male','Aneesh','Non-veg','AtCloud','L','U86737','U68142','2020-03-04 13:10:22','EWS','Trivandrum'),
(79,'sxk624','saran.kuttappan@equifax.com','Male','Saran','Non-veg','AtCloud','M','U36127','U68142','2020-03-04 13:10:22','EWS','Trivandrum'),
(80,'vxv127','vijith.vijayan@equifax.com','Male','Vijith','Non-veg','AtCloud','L','144534','U68142','2020-03-04 13:10:22','EWS','Trivandrum'),
(81,'msp8','mahesh.pillai@equifax.com','Male','Mahesh S','Veg','Newbies','L','U43006','U43006','2020-03-04 14:26:12','EWS','Trivandrum'),
(82,'sxg246','smitha.gireesan@equifax.com','Female','Smitha Gireesan','Non-veg','Newbies','M','U39024','U43006','2020-03-04 14:26:12','EWS','Trivandrum'),
(83,'sxr366','sherin.rajan@equifax.com','Female','Sherin Rajan','Veg','Newbies','M','u54352','U43006','2020-03-04 14:26:12','EWS','Trivandrum'),
(84,'axa479','Amitha.abhraham@equifax.com','Female','Amitha Abhraham','Non-veg','Newbies','M','U80829','U43006','2020-03-04 14:26:12','EWS','Trivandrum'),
(85,'mxs700','mohammad.shameer@equifax.com','Male','Mohammad Shameer','Non-veg','Tech Pirates','XL','u89249','u80830','2020-03-04 14:51:42','International-Australia/Cyber','Trivandrum'),
(86,'nxf55','neetha.fazily@equifax.com','Female','Neetha Fazily','Non-veg','Tech Pirates','L','u80830','u80830','2020-03-04 14:51:42','International-Australia/Cyber','Trivandrum'),
(87,'jxe128','john.elengickal2@equifax.com','Male','John Elengickal','Non-veg','Tech Pirates','XL','u45985','u80830','2020-03-04 14:51:42','International-Australia/Cyber','Trivandrum'),
(88,'sxv224','swetha.vp@equifax.com','Female','Swetha VP','Non-veg','Tech Pirates','L','143449','u80830','2020-03-04 14:51:42','International-Australia/Cyber','Trivandrum'),
(89,'uxn9','uthra.natarajan@equifax.com','Female','Uthra Thillai Natarajan','Non-veg','Hunter Squad','M','U48667','U48667','2020-03-04 15:00:00','USIS','Kochi'),
(90,'sxs1369','sreekanth.soman@equifax.com','Male','Sreekanth Soman','Non-veg','Hunter Squad','XL','U49935','U48667','2020-03-04 15:00:00','USIS','Kochi'),
(91,'axt214','andrew.thankachan@equifax.com','Male','Andrew Thankachan','Non-veg','Hunter Squad','M','U54362','U48667','2020-03-04 15:00:00','USIS','Kochi'),
(92,'vxn54','vineeth.neelakantan@equifax.com','Male','Vineeth Neelakantan','Non-veg','Hunter Squad','XL','U42526','U48667','2020-03-04 15:00:00','USIS','Kochi'),
(93,'axs1150','arjun.sivasankaran@equifax.com','Male','Arjun','Non-veg','Techdroidz ','M','144550','144550','2020-03-04 15:08:22','USIS','Kochi'),
(94,'nxj115','naveen.john@equifax.com','Male','Naveen','Non-veg','Techdroidz ','L','147283','144550','2020-03-04 15:08:22','USIS','Kochi'),
(95,'jxd418','joel.davis@equifax.com','Male','Joel','Veg','Techdroidz ','M','u66828','144550','2020-03-04 15:08:22','USIS','Kochi'),
(96,'lxi18','lincy.ignus@equifax.com','Female','Lincy','Veg','Techdroidz ','L','141746','144550','2020-03-04 15:08:22','USIS','Kochi'),
(97,'ext100','elbin.thomas@equifax.com','Male','Elbin Pallimalil','Non-veg','Snowflakes','XXL','145929','145929','2020-03-04 16:43:31','International-Canada','Kochi'),
(98,'rxp366','reju.pillai@equifax.com','Male','Reju Pillai','Non-veg','Snowflakes','L','U24431','145929','2020-03-04 16:43:31','International-Canada','Kochi'),
(99,'jxm711','Jasarudheen.Manjappalan@equifax.com','Male','Jasarudheen Manjappalan','Non-veg','Snowflakes','M','147051','145929','2020-03-04 16:43:31','International-Canada','Kochi'),
(100,'sxs1402','sruthy.selvan@equifax.com','Female','Sruthi MS','Non-veg','Snowflakes','S','147591','145929','2020-03-04 16:43:31','International-Canada','Kochi'),
(101,'sxu28','satheesh.unnikrishnan@equifax.com','Male','Satheesh Unnikrishnan','Non-veg','Tech Warriors','L','u16106','u16106','2020-03-04 16:44:14','EWS','Trivandrum'),
(102,'vxs226','vishnu.sankarramakrishnapillai@equifax.com','Male','Vishnu Sankar','Non-veg','Tech Warriors','M','u63560','u16106','2020-03-04 16:44:14','EWS','Trivandrum'),
(103,'rxj182','rinta.jose@equifax.com','Female','Rinta Mariam Jose','Non-veg','Tech Warriors','S','145376','u16106','2020-03-04 16:44:14','EWS','Trivandrum'),
(104,'axj346','arun.james@equifax.com','Male','Arun James','Non-veg','Tech Warriors','L','149380','u16106','2020-03-04 16:44:14','EWS','Trivandrum'),
(105,'mxk317','Manoj.kumar3@equifax.com','Male','Manoj Kumar','Non-veg','Cloud Geeks','M','U93608','U93608','2020-03-04 19:08:36','USIS','Trivandrum'),
(106,'vxs206','vinu.sivaraman@equifax.com','Female','Vinu sivaraman','Veg','Cloud Geeks','M','U60185','U93608','2020-03-04 19:08:36','USIS','Trivandrum'),
(107,'bxk133','binu.kumari@equifax.com','Male','Binu Kumari','Non-veg','Cloud Geeks','L','145594','U93608','2020-03-04 19:08:36','USIS','Trivandrum'),
(108,'sxm546','sajin.muhammed@equifax.com','Male','Sajin Mohammed','Non-veg','Cloud Geeks','S','U35382','U93608','2020-03-04 19:08:36','USIS','Trivandrum'),
(109,'nxn44','nidheesh.namboodiri@equifax.com','Male','Nidheesh Namboodiri','Veg','Cloud Ninjas','XXXL','u52355','u52355','2020-03-05 14:21:12','EWS','Trivandrum'),
(110,'bxl70','binoosha.leela@equifax.com','Female','Binoosha Leela Velappan Nair','Non-veg','Cloud Ninjas','L','U42342','u52355','2020-03-05 14:21:12','EWS','Trivandrum'),
(111,'axs905','ajithkumar.somashekharan@equifax.com','Male','Ajith Kumar Ettivilayil Somasekharan','Non-veg','Cloud Ninjas','M','U73157','u52355','2020-03-05 14:21:12','EWS','Trivandrum'),
(112,'dxc312','dhanuj.cherian@equifax.com','Male','Dhanuj Cherian','Non-veg','Cloud Ninjas','L','U89239','u52355','2020-03-05 14:21:12','EWS','Trivandrum'),
(113,'vxn48','vijitha.narayanan@equifax.com','Female','Vijitha Narayanan','Veg','Cloud Amigos','L','U52958','U52958','2020-03-05 15:15:25','EWS','Trivandrum'),
(114,'axh288','akhil.hariharan@equifax.com','Male','Akhil Hariharan','Non-veg','Cloud Amigos','M','U78774','U52958','2020-03-05 15:15:25','EWS','Trivandrum'),
(115,'sxa189','shine.abraham@equifax.com','Male','Shine Abraham','Non-veg','Cloud Amigos','XXL','U43658','U52958','2020-03-05 15:15:25','EWS','Trivandrum'),
(116,'dxs428','diya.suma@equifax.com','Female','Diya Suma','Non-veg','Cloud Amigos','XL','U68143','U52958','2020-03-05 15:15:25','EWS','Trivandrum'),
(121,'vxr83','vishakh.rameshan@equifax.com','Male','Vishakh Rameshan','Non-veg','Tech Seekers on Cloud','L','vxr83','vxr83','2020-03-05 16:09:46','USIS','Trivandrum'),
(122,'mxa341','manu.antony2@equifax.com','Male','Manu Antony','Veg','Tech Seekers on Cloud','M','U42043','vxr83','2020-03-05 16:09:46','USIS','Trivandrum'),
(123,'axk396','ajaya.kumari@equifax.com','Male','Ajaya Kumari','Non-veg','Tech Seekers on Cloud','L','U48217','vxr83','2020-03-05 16:09:46','USIS','Trivandrum'),
(124,'bxb197','bhawesh.bhasker@equifax.com','Male','Bhawesh Bhasker','Non-veg','Tech Seekers on Cloud','XL','U60844','vxr83','2020-03-05 16:09:46','USIS','Trivandrum'),
(125,'lxl130','libin.lougine@equifax.com','Male','Libin Lougine L','Non-veg','CORONA','XL','U63587','U63587','2020-03-05 18:31:18','USIS','Trivandrum'),
(126,'rxk316','rakesh.krishnannair@equifax.com','Male','Rakesh Krishnan Nair','Non-veg','CORONA','XL','U72031','U63587','2020-03-05 18:31:18','USIS','Trivandrum'),
(127,'lxl173','ligin.lougine@equifax.com','Male','Ligin Lougine L','Non-veg','CORONA','XL','141166','U63587','2020-03-05 18:31:18','USIS','Trivandrum'),
(128,'rxg78','rakesh.gopinathan@equifax.com','Male','Rakesh Gopinathan','Non-veg','CORONA','L','U28808','U63587','2020-03-05 18:31:18','USIS','Trivandrum'),
(129,'pxk163','pravee.kumar@equifax.com','Male','Praveen Kumar','Non-veg','NIPAH','XL','U57360','U57360','2020-03-05 18:50:59','USIS','Trivandrum'),
(130,'axs964','amal.sankar@equifax.com','Male','Amal Sankar','Non-veg','NIPAH','L','U91158','U57360','2020-03-05 18:50:59','USIS','Trivandrum'),
(131,'jxv156','jijo.varghese@equifax.com','Male','Jijo Varghese','Non-veg','NIPAH','L','U60516','U57360','2020-03-05 18:50:59','USIS','Trivandrum'),
(132,'hxa90','hitesh.anant@equifax.com','Male','Hitesh Anant','Non-veg','NIPAH','XL','U110974','U57360','2020-03-05 18:50:59','USIS','Trivandrum'),
(137,'sxs1315','shemeer.sherif@equifax.com','Male','SHEMEER SHERIF','Non-veg','BROCODE CLAN','XL','U84902','U84902','2020-03-06 12:01:23','International-UK','Trivandrum'),
(138,'mxb511','maneesh.babu@equifax.com','Male','MANEESH BABU','Non-veg','BROCODE CLAN','XL','u81340','U84902','2020-03-06 12:01:23','International-UK','Trivandrum'),
(139,'U87099','Sujith.Sundaresan@ust-global.com','Male','SUJITH KUMAR ','Non-veg','BROCODE CLAN','XXL','U87099','U84902','2020-03-06 12:01:23','International-UK','Trivandrum'),
(140,'mxm817','manu.muthulekshmy@equifax.com','Male','MANU MUTHULEKSHMY','Non-veg','BROCODE CLAN','M','U146214','U84902','2020-03-06 12:01:23','International-UK','Trivandrum'),
(157,'hxs197','hussain.sheriff@equifax.com','Male','Hussain Sheriff','Non-veg','G Stadia','L','U94427','U94427','2020-03-06 12:19:25','USIS','Trivandrum'),
(158,'hxk113','hari.krishna@equifax.com','Male','Hari Krishna','Non-veg','G Stadia','XL','140626','U94427','2020-03-06 12:19:25','USIS','Trivandrum'),
(159,'bxr125','baskaran.rajendran@equifax.com','Male','Baskaran Rajendran','Non-veg','G Stadia','XL','U60277','U94427','2020-03-06 12:19:25','USIS','Trivandrum'),
(160,'sxn234','shreeraj.nair@equifax.com','Male','Shreeraj Nair','Non-veg','G Stadia','L','U35295','U94427','2020-03-06 12:19:25','USIS','Trivandrum'),
(161,'axr524','arunkumar.rajamani@equifax.com','Male','Arunkumar Rajamani','Non-veg','Zika','M','145869','145869','2020-03-06 15:03:20','USIS','Trivandrum'),
(162,'gxt99','godfray.thomas@equifax.com','Male','Godfray Thomas','Non-veg','Zika','M','102114','145869','2020-03-06 15:03:20','USIS','Trivandrum'),
(163,'txh197','thoufeeq.hameed@equifax.com','Male','Thoufeeq Hameed ','Non-veg','Zika','M','U92302','145869','2020-03-06 15:03:20','USIS','Trivandrum'),
(164,'vxb130','visakh.bindhu@equifax.com','Male','Visakh Bindhu ','Non-veg','Zika','M','139594','145869','2020-03-06 15:03:20','USIS','Trivandrum'),
(166,'nxv73','Niran.V@equifax.com','Male','Niran Vijayakumar','Non-veg','Up in the Cloud','L','U48092','U48092','2020-03-06 16:25:50','International-Canada','Trivandrum'),
(167,'vxg75','vivek.gopakumar@equifax.com','Male','Vivek Gopakumar','Non-veg','Up in the Cloud','L','U47385','U48092','2020-03-06 16:25:50','EWS','Trivandrum'),
(168,'mxk310','midhun.krishna@equifax.com','Male','Midhun Krishna','Non-veg','Up in the Cloud','L','u92654','U48092','2020-03-06 16:25:50','International-UK','Trivandrum'),
(169,'djp8','dilli.pillai@equifax.com','Male','Dilli Pillai','Non-veg','Up in the Cloud','M','U73135','U48092','2020-03-06 16:25:50','USIS','Trivandrum'),
(170,'rxn102','Rani.Nair@equifax.com','Female','Rani Nair','Non-veg','International','M','U15422','U15422','2020-03-06 16:46:08','International-UK','Trivandrum'),
(171,'sxs1081','Stejith.Stephen@equifax.com','Male','Stejith Stephen','Non-veg','International','M','U75149','U15422','2020-03-06 16:46:08','International-Australia/Cyber','Trivandrum'),
(172,'dxk221','Dona.Kurian@equifax.com','Female','Dona Ann Kurian','Veg','International','S','U80833','U15422','2020-03-06 16:46:08','International-Australia/Cyber','Trivandrum'),
(173,'sxr407','Seema.Raj@equifax.com','Female','Seema Raj','Non-veg','International','L','U37015','U15422','2020-03-06 16:46:08','International-Australia/Cyber','Trivandrum'),
(182,'sxk686','shashank.kamath@equifax.com','Male','Shashank Kamath','Non-veg','Cloud Squad','XL','u80297','u80297','2020-03-06 17:31:15','USIS','Trivandrum'),
(183,'rxr316','reshmi.rema@equifax.com','Female','Reshmi Rema','Non-veg','Cloud Squad','XXL','U67119','u80297','2020-03-06 17:31:15','USIS','Trivandrum'),
(184,'sxs894','sreerekha.santha@equifax.com','Female','Sreerekha Santha','Non-veg','Cloud Squad','XL','U15423','u80297','2020-03-06 17:31:15','USIS','Trivandrum'),
(185,'txm129','tinkle.mathew@equifax.com','Male','Tinkle Mathew','Veg','Cloud Squad','L','U47755','u80297','2020-03-06 17:31:15','USIS','Trivandrum'),
(186,'axs970','aswathi.santhosh@equifax.com','Female','ASWATHI SANTHOSH','Veg','ALPHA','XL','U50304','U50304','2020-03-06 18:06:29','USIS','Trivandrum'),
(187,'sxt239','sethulekshmi.thara@equifax.com','Female','SETHULEKSHMI THARA','Non-veg','ALPHA','M','U52176','U50304','2020-03-06 18:06:29','USIS','Trivandrum'),
(188,'abr5','arunraj.radhamony@equifax.com','Male','Arun Raj','Non-veg','ALPHA','L','u87931','U50304','2020-03-06 18:06:29','USIS','Trivandrum'),
(193,'axk515','ajay.kannampallil@equifax.com','Male','Ajay Kannampallil','Non-veg','Meghayana','XXL','u92062','u92062','2020-03-06 19:03:20','USIS','Trivandrum'),
(194,'mxp436','midhun.prem@equifax.com','Male','Midhun Prem','Non-veg','Meghayana','XL','147760','u92062','2020-03-06 19:03:20','USIS','Trivandrum'),
(195,'bxv58','binoy.varghese@equifax.com','Male','Binoy Varghese','Veg','Meghayana','L','141171','u92062','2020-03-06 19:03:20','USIS','Trivandrum'),
(196,'lxn58','lekshmy.nair@equifax.com','Female','Lekshmy Nair','Non-veg','Meghayana','L','U63135','u92062','2020-03-06 19:03:20','USIS','Trivandrum'),
(198,'vkm3','vighnesh.m@equifax.com','Male','Vighnesh','Non-veg','Thunder Storm','M','U59976','U60819','2020-03-06 19:53:20','USIS','Trivandrum'),
(199,'nxj111','noel.john@equifax.com','Male','Noel','Non-veg','Thunder Storm','M','143284','U60819','2020-03-06 19:53:20','USIS','Trivandrum'),
(200,'jxm541','john.mathew@equifax.com','Male','John','Non-veg','Thunder Storm','L','U63600','U60819','2020-03-06 19:53:20','USIS','Trivandrum');

/*Table structure for table `role` */

DROP TABLE IF EXISTS `role`;

CREATE TABLE `role` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `role` */

insert  into `role`(`id`,`name`) values 
(1,'Employee'),
(2,'Admin');

/*Table structure for table `user` */

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `password` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `created` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=60 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `user` */

insert  into `user`(`id`,`password`,`username`,`created`) values 
(1,'$2a$10$OV2KDmcUckjq3ohDmrJsA.ruy1iptNnM4N/Qf4kzjylwsTqG5SC8q','u52355',NULL),
(2,'$2a$10$w7czcJRSUi4m4Vvbh3XPjuh6qdS7b/yTTpL/lQbkBuyxHFiwYGPzm','u47804',NULL),
(3,'$2a$10$D1Jx0zZeeslJI0sYpI0N9O30ymddebnLmchX1Ew0OExtytbv3BpyW','U54548',NULL),
(4,'$2a$10$aBKh2VPimBonF/KiJ.YKw.hhdAtB5o0ke8qK2cM3ApmTS0FoCQgne','u28878',NULL),
(5,'$2a$10$Ys9oU2HiuCmdFLJaxRnTguiaq4hwtxYcF.7huRUZ0VWjmbrqMlP/W','u12695',NULL),
(6,'$2a$10$mhCstvRR/l5kbBhZ7BCa6.Tv.tXVuWT9iqr5V2UdRsZGOTH/Lk48m','U93608',NULL),
(7,'$2a$10$L6WMK9d9JutZ9E7V3UOcWuduGnVE1ORav6FOxXvecI/vk2J4S49bK','145550',NULL),
(8,'$2a$10$WM2.4xgokdSqeAM57lJ1.uvVh7W/bsThWx0MqUNNSMKISkTwsdFfy','U59689',NULL),
(9,'$2a$10$j0DD9TZHpQXef9z12s8Qo.FgB1sF/oRQ61S1aCpz2ge7q484cXJF6','U47240',NULL),
(10,'$2a$10$Kx6B/LkvB36r4uB9DdeV5erYyuw/1CNxWaTiRYVNjqkElW62kYyVK','U60819',NULL),
(11,'$2a$10$tjDmV7oIyKplm9g4glpoL.445wbPRcw0sM0ggfTXUKtmwrXC26lK.','U83654',NULL),
(12,'$2a$10$FfVA.AKsJM5Pm9U05A1siuVisbrkJPmijMnoO22t6zNDPD2sOKZXO','U55687',NULL),
(13,'$2a$10$Mm.nAGNPmMNP4Z9j3K8B4ulv9MdHBD1Rt0MHNuVGuJT/gUYPbuBEW','U63660',NULL),
(14,'$2a$10$6FGHZQXwy7VaiIHNfu0zx.HjBoBWf/rlgv1.83YOhfBWKfM87kg9m','u82705',NULL),
(15,'$2a$10$GUHwL6VYLyin5jixB5teDOxfkWF9gIrJiPdFiGhb5L/9A46tf/12e','U59976',NULL),
(16,'$2a$10$QuE5KmXv/1K5ssOlXljgAOVIIRu0FwaGtFd.H9mBnmvD/BWk8ayq2','admin',NULL),
(17,'$2a$10$ghEjS.FRvziPsoSQOo3zl.b2Ze/Zdq8GQh97NQCra3WDw94S/CfFW','u63201',NULL),
(18,'$2a$10$gNI.uvKxB5Hm0WKGE70ukeckGmP3MSRy0PTKOe1MVZAjPqSbgdu..','U47139',NULL),
(19,'$2a$10$8uHc8lKD0LyScIERN6CDFOtN34z3eRIVai0jBlQf1r.OYKWUFD.vq','u89249',NULL),
(20,'$2a$10$Cukt49esCxlYRPDjCRU3V.t7A8UZ1/hPwYznQXMzCF9qNZBCfTTim','U43231',NULL),
(21,'$2a$10$YNabJIF9LnJPLVzeBofqx.C3sL95jR76Z83N2PtnY3nl.YHfqdrGi','u80830',NULL),
(22,'$2a$10$1mWQ7ulFVHQUgNT0U3Ammu71gQQlKYxWDn/1AN532zp61tXnkPqRK','xyz123',NULL),
(23,'$2a$10$HtluyDci01Os7dIL78AHbub3lHswgjbZ7aE7A81ea32.W8nESpBEK','u36127',NULL),
(24,'$2a$10$YDdoZv4WyigvWtG.6y8VMuo9MUd19OM5xkj9jspL7jtpqQ6wjzjXq','U52958',NULL),
(25,'$2a$10$gUh.OBSvrOwpbYEoc0BQyuTvV8ezYj5buAAIMOsYOeG5298R9DejW','145929',NULL),
(26,'$2a$10$Dlwh5ySeaO4yIQlazo3IsewM.mdSmXE9Kc5n/mAWYOP952zyoFaeu','U82284',NULL),
(27,'$2a$10$pAcYWOkPXB7qwBqDDf2Ah.lNo7i8LBaupMQpWmuKdBFj.dzqcYTWO','u49583','2020-03-03 14:24:52.582000'),
(28,'$2a$10$kwDssoBUhpUaO7NleDs7BejyYdxjdsU0SoSTjtomFTw5Klf8ow8cq','U48092','2020-03-03 15:32:41.514000'),
(29,'$2a$10$WQx19m9C0GwlbXUhvc4jPenlTw96so.1ljmh2IA7oYwZPYGxeiCq6','U59650','2020-03-03 15:36:41.942000'),
(30,'$2a$10$U5Cfl4LeMKJ6JZ7KudaMRuZj1lQGVhpmEhfcGMj9hiymEwIXx0CFq','146670@ust-global.com','2020-03-03 16:59:18.749000'),
(31,'$2a$10$75uydc7VI.eq9E69dr3t1.E8mHyBPbSOs1FFIFqk9u9tYWGIqFOGm','u42526`','2020-03-03 17:01:05.715000'),
(32,'$2a$10$KFgce8IENOpB5zz2hmBgCe.5eVwlU999pOKnCv6G6MlD2uWnkBELO','146670','2020-03-03 17:29:47.438000'),
(33,'$2a$10$yK/VrqFuu4U2qFETskhyJO7z8ksEcPvcb00aSXPTdeERZ4DtliEyy','U14650','2020-03-03 17:49:44.154000'),
(34,'$2a$10$EK53i3TiX6riB8MZCii1LOASLn1QOKAmquENb.LAc/P2l68nWtKVS','U82884','2020-03-03 17:59:27.530000'),
(35,'$2a$10$QePVpBWfwSpTfNVBcLw/uuaVnDo2/W.9EWMIttvRZRrUyG4ElK0QG','U48667','2020-03-03 18:01:18.934000'),
(36,'$2a$10$x7reJWUTaRUfNOVXx30GjOdMzFNOjg6nC8G5vi0eHFjYBaOv4TtnG','u91162','2020-03-04 11:29:09.667000'),
(37,'$2a$10$Mq8BewRor/9HIOwqEyBg9ehMCjOJrXoBXFwGCizS1OpjHtabs7HIm','U43006','2020-03-04 12:36:50.839000'),
(38,'$2a$10$QXXsELSUJm5haXyd2qi2/ed/CfgYgeG016Fz5NkGzcr2hTgfKQZL.','U68142','2020-03-04 12:58:14.281000'),
(39,'$2a$10$Avt4m4aIzTWvwezyqVXAZuTLbtFC3zitqI.RR4FVBzf.Q.dvw8w9y','nxp190','2020-03-04 14:56:35.670000'),
(40,'$2a$10$ecrcKrLgiepsqQs0irEy9Oz64BJBeQ9RilApxl46tuRvfnHB5UkjK','144550','2020-03-04 14:57:28.319000'),
(41,'$2a$10$suy1egADhkHDAARZLSWjFOfXgLZ4vCorAZUr0SLXoblLdzVltiR6e','U24431','2020-03-04 15:24:54.422000'),
(42,'$2a$10$yM5nxVyQZEOiehq.VDDg6.nqTAnFmJoKBV9XK.lFtuIwpGDPVVBBi','u16106','2020-03-04 16:20:22.986000'),
(43,'$2a$10$vD1QnZN0TCKF.j06B3O4u.Erd.oJet9znuH9Gi7mJpiWbqloe5m7a','U61266','2020-03-04 17:46:16.645000'),
(44,'$2a$10$1wqyQy7FtAf0SXkmqBp7Nefvkhav2a1oabfBY0wh5vWZyvgX2Pxs2','u92062','2020-03-04 17:53:48.804000'),
(45,'$2a$10$1TB7NFaHYwTNEZP9FhFsUeI..K8pxMYfaRiNKtK8fGVr/K7aPwGmm','vxr83','2020-03-04 19:19:25.904000'),
(46,'$2a$10$W1iEVJpMXZ0Dd98cj.u92.a7JrhpJiylCn6AbjYnC734LCXdvalJO','139594@ust-global.com','2020-03-05 12:01:03.076000'),
(47,'$2a$10$jEEVFujzdYu0rofzCetDc.oxNAI6XwELIf1PYWSFNqRRu4s05YiYO','U50304','2020-03-05 12:01:25.469000'),
(48,'$2a$10$V8N5fq5ckLyCvxS6wJD5Re5CYkMj4PASe.NVzbKcIG0979jmIeXAe','u50265','2020-03-05 15:23:41.826000'),
(49,'$2a$10$zyZ85rrAhrupOsF0qzeWB.W0aCwbBFRIc2OaUYZW0x1fBE3BT3Bz6','U63587','2020-03-05 18:22:49.687000'),
(50,'$2a$10$FNNzXQjGsJi8/5GtRI0af.DTjhm3LW4bqnWbmxRP9MJHSc8IYrxwe','U57360','2020-03-05 18:32:52.714000'),
(51,'$2a$10$vDJxIFSjN5YNfHb7es0FhuY/hK1jcfTxIKiymCIf7JI8ryDUls8f.','U84902','2020-03-06 11:49:03.319000'),
(52,'$2a$10$ffm2ibyUzx0PrfDSySTwPeya.gDFHI7DtIiUIDhLr8s0K3VtgjQ4W','U94427','2020-03-06 11:56:20.580000'),
(53,'$2a$10$8Fw1myPl4AcUIxGtu2BR7ufQ2qyfN1or4ev2R7wWzbON7nl.mp6Q2','U59138','2020-03-06 12:08:35.652000'),
(54,'$2a$10$mTz2G0p1r3qB17XjIRaMNeTdB4FLDcE7pUTKPFhK92gdVO1JPrOKW','91158','2020-03-06 14:50:26.046000'),
(55,'$2a$10$FgbAw1ujVNBd4Ox4Y1yshOTbJVAOamfL6GIqVOmnPQjTuliQRNVSK','145869','2020-03-06 14:51:02.919000'),
(56,'$2a$10$4J6pig4BLC7x.W7p2X03eO0P6KhWCPrLAU7yF0D61xXhxzn9ol9nC','U15422','2020-03-06 16:33:47.014000'),
(57,'$2a$10$UzVYmKAzj54.1jPZh/BYwO6yv5mK3oTk9zEHPe5TX7cHSj2QYYaBm','u80297','2020-03-06 17:00:28.347000'),
(58,'$2a$10$XvBzH/RTTK/aWTvdqlXInOaeaZkjCp2XT/i1dey5aPMVV5BOLqfpq','141171','2020-03-06 18:12:23.878000'),
(59,'$2a$10$nLPlSy4/5woUCJXx4b7SkOnb.Psijwc3LphWFoXsKlNpxaUzR9H.2','143284','2020-03-06 19:15:33.732000');

/*Table structure for table `user_roles` */

DROP TABLE IF EXISTS `user_roles`;

CREATE TABLE `user_roles` (
  `users_id` bigint(20) NOT NULL,
  `roles_id` bigint(20) NOT NULL,
  PRIMARY KEY (`users_id`,`roles_id`),
  KEY `FKj9553ass9uctjrmh0gkqsmv0d` (`roles_id`),
  CONSTRAINT `FK7ecyobaa59vxkxckg6t355l86` FOREIGN KEY (`users_id`) REFERENCES `user` (`id`),
  CONSTRAINT `FKj9553ass9uctjrmh0gkqsmv0d` FOREIGN KEY (`roles_id`) REFERENCES `role` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `user_roles` */

insert  into `user_roles`(`users_id`,`roles_id`) values 
(1,1),
(2,1),
(3,1),
(4,1),
(5,1),
(6,1),
(7,1),
(8,1),
(9,1),
(10,1),
(11,1),
(12,1),
(13,1),
(14,1),
(15,1),
(17,1),
(18,1),
(19,1),
(20,1),
(21,1),
(22,1),
(23,1),
(24,1),
(25,1),
(26,1),
(27,1),
(28,1),
(29,1),
(30,1),
(31,1),
(32,1),
(33,1),
(34,1),
(35,1),
(36,1),
(37,1),
(38,1),
(39,1),
(40,1),
(41,1),
(42,1),
(43,1),
(44,1),
(45,1),
(46,1),
(47,1),
(48,1),
(49,1),
(50,1),
(51,1),
(52,1),
(53,1),
(54,1),
(55,1),
(56,1),
(57,1),
(58,1),
(59,1),
(16,2);

/*Table structure for table `volunteers` */

DROP TABLE IF EXISTS `volunteers`;

CREATE TABLE `volunteers` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `efx_id` varchar(255) NOT NULL,
  `emp_email` varchar(255) NOT NULL,
  `emp_gender` varchar(255) NOT NULL,
  `emp_name` varchar(255) NOT NULL,
  `food_type` varchar(255) NOT NULL,
  `tshirt_size` varchar(255) NOT NULL,
  `uid` varchar(255) DEFAULT NULL,
  `created` datetime(6) DEFAULT NULL,
  `emp_account` varchar(255) NOT NULL,
  `location` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UK_e73n86mrmfvq48wgsy7q4e39k` (`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `volunteers` */

insert  into `volunteers`(`id`,`efx_id`,`emp_email`,`emp_gender`,`emp_name`,`food_type`,`tshirt_size`,`uid`,`created`,`emp_account`,`location`) values 
(1,'mxm560','mukesh.muraleedharanpillai@equifax.com','Male','Mukesh M','Non-veg','XXL','U12695','2020-03-10 12:18:49.570000','Emerging Market','Trivandrum');

/*Table structure for table `winners` */

DROP TABLE IF EXISTS `winners`;

CREATE TABLE `winners` (
  `id` bigint(20) NOT NULL,
  `map` varchar(255) DEFAULT NULL,
  `team_name` varchar(255) NOT NULL,
  `team_name2` varchar(255) NOT NULL,
  `team_name3` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `winners` */

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
